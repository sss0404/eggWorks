/**
 * Created by yingxiaosheng on 13-12-9.
 */

function jsonParse(obj){
    if(obj){
        return  JSON.parse(obj);
    }else{
        return  null;
    }
}

//基金数据模型
function TradableFund () {
    //基金名称
    this.fundName = "";
    //基金代码
    this.fundCode = "";
    //份额方式[前段or后端]
    this.fundShareType = "";
    //基金类型
    this.fundType = "";
    //基金状态
    this.fundState = "";
    //基金风险等级
    this.fundRiskLevel = "";
    //基金最低保留份额
    this.fundMinShares = 1000;
    //是否开发申购
    this.declareState = true;
    //最低申购金额
    this.purchaseLimitMin = 1000;
    //最大申购金额
    this.purchaseLimitMax = 10000000;
    //是否开发认购
    this.subscribeState = false;
    //最低认购金额
    this.subscribeLimitMin = 1000;
    //最大认购金额
    this.subscribeLimitMax = 10000000;
    //是否开发赎回
    this.withdrawState = true;
    //最低赎回份额
    this.redeemLimitMin = 1000;
    //最大赎回份额
    this.redeemLimitMax = 10000000;
    //是否开发定投
    this.trendState = true;

    this.saveToSessionStorage = function() {
        sessionStorage.setItem("TradableFund", JSON.stringify(this));
    };
    this.saveToLocalStorage = function() {
        localStorage.setItem("TradableFund", JSON.stringify(this));
    };
    this.getInstanceFromSessionStorage = function() {
        var obj = jsonParse(sessionStorage.getItem("TradableFund"));
        if (obj) {
            var fund = new TradableFund();
            for (var name in obj) {
                fund[name] = obj[name];
            }
            return fund;
        }
        return null;
    };
    this.getInstanceFromLocalStorage = function() {
        var obj = jsonParse(localStorage.getItem("TradableFund"));
        if (obj) {
            var fund = new TradableFund();
            for (var name in obj) {
                fund[name] = obj[name];
            }
            return fund;
        }
        return null;
    };
}

//用户数据模型
function User() {
    //属性
    this.tokenKey = "";
    this.tokenSecret = "";
    this.userName = "";
    this.realName = "";
    this.certificateNumber = "";
    this.certificateType = "";
    this.email = "";
    this.mobile = "";
    this.photo = "";
    this.userStatus = 0;
    this.riskAbility = "";
    this.riskExpired = "";
    this.tempTradePassword = false;
    this.defaultLoginPssword = false;
    this.bindedBankCards = [];
    this.openAccountTimusere = "";

    this.saveToSessionStorage = function() {
        sessionStorage.setItem("User", JSON.stringify(this));
    };
    this.saveToLocalStorage = function() {
        localStorage.setItem("User", JSON.stringify(this));
    };
    this.getInstanceFromSessionStorage = function() {
        var obj =jsonParse (sessionStorage.getItem("User"));
        if (obj) {
            var user = new User();
            for (var name in obj) {
                user[name] = obj[name];
            }
            return user;
        }
        return null;
    };
    this.getInstanceFromLocalStorage = function() {
        var obj = jsonParse(localStorage.getItem("User"));
        if (obj) {
            var user = new User();
            for (var name in obj) {
                user[name] = obj[name];
            }
            return user;
        }
        return null;
    };
}

//开户数据模型
function OpenAccountModel () {
    //属性
    this.realName = "";
    this.certificateNumber = "";
    this.certificateType = "";
    this.mobile = "";
    this.email = "";
    this.tradePassword = "";
    this.bankCardNo = "";
    this.bankSerial = "";
    this.provinceCode = "";
    this.cityCode = "";
    this.subbranchCode = "";
    this.bankMobile = "";
    this.bindWay = "";
    this.capitalMode = "";

    this.saveToSessionStorage = function() {
        sessionStorage.setItem("OpenAccountModel", JSON.stringify(this));
    };
    this.saveToLocalStorage = function() {
        localStorage.setItem("OpenAccountModel", JSON.stringify(this));
    };
    this.getInstanceFromSessionStorage = function() {
        var obj =jsonParse (sessionStorage.getItem("OpenAccountModel"));
        if (obj) {
            var model = new OpenAccountModel();
            for (var name in obj) {
                model[name] = obj[name];
            }
            return model;
        }
        return null;
    };
    this.getInstanceFromLocalStorage = function() {
        var obj = jsonParse(localStorage.getItem("OpenAccountModel"));
        if (obj) {
            var model = new OpenAccountModel();
            for (var name in obj) {
                model[name] = obj[name];
            }
            return model;
        }
        return null;
    };
}

//开户参数
function OpenAccountParam () {
    //属性
    this.realName = "";
    this.certificateNumber = "";
    this.mobile = "";
    this.email = "";

    this.saveToSessionStorage = function() {
        sessionStorage.setItem("OpenAccountParam", JSON.stringify(this));
    };
    this.saveToLocalStorage = function() {
        localStorage.setItem("OpenAccountParam", JSON.stringify(this));
    };
    this.getInstanceFromSessionStorage = function() {
        var obj =jsonParse (sessionStorage.getItem("OpenAccountParam"));
        if (obj) {
            var model = new OpenAccountParam();
            for (var name in obj) {
                model[name] = obj[name];
            }
            return model;
        }
        return null;
    };
    this.getInstanceFromLocalStorage = function() {
        var obj = jsonParse(localStorage.getItem("OpenAccountParam"));
        if (obj) {
            var model = new OpenAccountParam();
            for (var name in obj) {
                model[name] = obj[name];
            }
            return model;
        }
        return null;
    };
}

//省份数据模型
function Province () {
    this.provinceCode = "";
    this.provinceName = "";
}

//城市数据模型
function City () {
    this.cityCode = "";
    this.cityName = "";
}

//支行数据模型

function Subbranch () {
    this.subbranchCode = "";
    this.subbranchName = "";
}

//银行卡数据模型
function BankCard () {
    //属性
    this.tradeAccount = "";
    this.bankSerial = "";
    this.bankName = "";
    this.bankCardNo = "";
    this.capitalMode = "";
    this.bindWay = 0;
    this.bankStatus = "";
    this.bankStatusToCN = "";
    this.bankMobile = "";
    this.isFreeze = false;
    this.isVaild = true;
    this.balance = 0;
    this.discountRate = 0;
    this.limitDescribe = "";
    this.contentDescribe = "";
    this.belongProvince = {};
    this.belongCity = {};
    this.belongSubbranch = {};

    this.saveToSessionStorage = function() {
        sessionStorage.setItem("BankCard", JSON.stringify(this));
    };
    this.saveToLocalStorage = function() {
        localStorage.setItem("BankCard", JSON.stringify(this));
    };
    this.getInstanceFromSessionStorage = function() {
        var obj = jsonParse(sessionStorage.getItem("BankCard"));
        if (obj) {
            var bankCard = new BankCard();
            for (var name in obj) {
                bankCard[name] = obj[name];
            }
            return bankCard;
        }
        return null;
    };
    this.getInstanceFromLocalStorage = function() {
        var obj = jsonParse(localStorage.getItem("BankCard"));
        if (obj) {
            var bankCard = new BankCard();
            for (var name in obj) {
                bankCard[name] = obj[name];
            }
            return bankCard;
        }
        return null;
    };
    this.isNYBankAndHYPChannel = function() {
        if (this.bankSerial == "003" && this.capitalMode == "6") {
            return true;
        }
        return false;
    };

    this.isYiBaoPayMoneyChannel = function () {
        if (this.capitalMode == "P" && this.bindWay == "2") {
            return true;
        }
        return false;
    };

    this.isHuiFuQuickWayChannel = function () {
        if (this.capitalMode == "6" && this.bindWay == "1") {
            return true;
        }
        return false;
    };

    this.getBankIconName = function () {
        var iconName;
        switch (this.bankSerial) {
            // 工行银行
            case "002":
            {
                iconName = "ICBC_logo.png";
            }
                break;
            // 农行银行
            case "003":
            {
                iconName = "ABC_logo.png";
            }
                break;
            // 中国银行
            case "004":
            {
                iconName = "BC_logo.png";
            }
                break;
            // 建设银行
            case "005":
            {
                iconName = "CCB_logo.png";
            }
                break;
            // 交通银行
            case "006":
            {
                iconName = "BCM_logo.png";
            }
                break;
            // 招行银行
            case "007":
            {
                iconName = "CMB_logo.png";
            }
                break;
            // 光大银行
            case "009":
            {
                iconName = "CEB_logo.png";
            }
                break;
            // 浦发银行
            case "010":
            {
                iconName = "SPDB_logo.png";
            }
                break;
            // 兴业银行
            case "011":
            {
                iconName = "CIB_logo.png";
            }
                break;
            // 民生银行
            case "014":
            {
                iconName = "CMBC_logo.png";
            }
                break;
            // 中信银行
            case "015":
            {
                iconName = "CITIC_logo.png";
            }
                break;
            // 广发银行
            case "016":
            {
                iconName = "GDB_logo.png";
            }
                break;
            // 上海银行
            case "017":
            {
                iconName = "BOS_logo.png";
            }
                break;
            // 温州银行
            case "907":
            {
                iconName = "BOW_logo.png"
            }
                break;
            // 平安银行
            case "920":
            {
                iconName = "PAB_logo.png";
            }
                break;
            // 邮政银行
            case "934":
            {
                iconName = "PSBC_logo.png";
            }
                break;
            // 渤海银行
            case "938":
            {
                iconName = "CBHB_logo.png";
            }
                break;
            // 重庆银行
            case "940":
            {
                iconName = "BOCQ_logo.png";
            }
                break;
            default :
                break;
        }
        return iconName;
    };
}

function FundTradeRecord () {
    this.applySerial = "";
    this.fundCode = "";
    this.fundName = "";
    this.shareType = "";
    this.shareTypeToCN = "";
    this.businessType = "";
    this.businessTypeToCN = "";
    this.bankCard = {};
    this.applyDateTime = "";
    this.amount = "";
    this.shares = "";
    this.poundAge = "";
    this.status = "";
    this.statusToCN = "";
    this.canCancel = "";
    this.payResult = "";
    this.payStatusToCN = "";

    this.init = function(id){
        if(typeof id == "object" && !shumi_sdk_isEmpty(id)){
            for(var propertyN in id){
                var propertyV = id[propertyN];
                if(propertyN == "bankCard" && propertyV.length > 0){
                    var bankCards = [];
                    for(var i = 0 ; i < propertyV.length ; i++){
                        var bankCard = new BankCard().init(propertyV[i]);
                        bankCards.push(bankCard);
                    }
                    propertyV = bankCards;
                }
                this[propertyN] = propertyV;
            }
            return this;
        }
        return new Object();
    };

    this.saveToSessionStorage = function () {
        sessionStorage.setItem("FundTradeRecord", JSON.stringify(this));
    };

    this.saveToLocalStorage = function () {
        localStorage.setItem("FundTradeRecord", JSON.stringify(this));
    };

    this.getInstanceFromSessionStorage = function () {
        var obj = jsonParse(sessionStorage.getItem("FundTradeRecord"));
        if (obj) {
            return this.init(obj);
        }
        return null;
    };

    this.getInstanceFromLocalStorage = function () {
        var obj = jsonParse(localStorage.getItem("FundTradeRecord"));
        if (obj) {
            return this.init(obj);
        }
        return null;
    };
}

//订单数据模型
function Oder () {
    this.orderID = "";
}

//认购订单
function SubscribeFundOrder () {
    this.subscribeFund = {};
    this.bankCard = {};
    this.applySum = 0;
    this.fee = 0;
    this.orderPaidTime = "";

    this.saveToSessionStorage = function() {
        sessionStorage.setItem("SubscribeFundOrder", JSON.stringify(this));
    };
    this.saveToLocalStorage = function() {
        localStorage.setItem("SubscribeFundOrder", JSON.stringify(this));
    };
    this.getInstanceFromSessionStorage = function() {
        var obj = jsonParse(sessionStorage.getItem("SubscribeFundOrder"));
        if (obj) {
            var order = new SubscribeFundOrder();
            for (var name in obj) {
                order[name] = obj[name];
            }
            return order;
        }
        return null;
    };
    this.getInstanceFromLocalStorage = function() {
        var obj = jsonParse(localStorage.getItem("SubscribeFundOrder"));
        if (obj) {
            var order = new SubscribeFundOrder();
            for (var name in obj) {
                order[name] = obj[name];
            }
            return order;
        }
        return null;
    };
}
SubscribeFundOrder.prototype = new Oder();

//申购订单
function PurchaseFundOder () {
    this.purchaseFund = {};
    this.bankCard = {};
    this.applySum = 0;
    this.fee = 0;
    this.orderPaidTime = "";

    this.saveToSessionStorage = function() {
        sessionStorage.setItem("PurchaseFundOder", JSON.stringify(this));
    };
    this.saveToLocalStorage = function() {
        localStorage.setItem("PurchaseFundOder", JSON.stringify(this));
    };
    this.getInstanceFromSessionStorage = function() {
        var obj = jsonParse(sessionStorage.getItem("PurchaseFundOder"));
        if (obj) {
            var order = new PurchaseFundOder();
            for (var name in obj) {
                order[name] = obj[name];
            }
            return order;
        }
        return null;
    };
    this.getInstanceFromLocalStorage = function() {
        var obj = jsonParse(localStorage.getItem("PurchaseFundOder"));
        if (obj) {
            var order = new PurchaseFundOder();
            for (var name in obj) {
                order[name] = obj[name];
            }
            return order;
        }
        return null;
    };
}
PurchaseFundOder.prototype = new Oder();

//赎回订单
function RedeemFundOder () {
    this.redeemFund = {};
    this.bankCard = {};
    this.applySum = 0;
    this.fee = 0;
    this.isQuick = false;
	this.arriveDate = "";

    this.saveToSessionStorage = function() {
        sessionStorage.setItem("RedeemFundOder", JSON.stringify(this));
    };
    this.saveToLocalStorage = function() {
        localStorage.setItem("RedeemFundOder", JSON.stringify(this));
    };
    this.getInstanceFromSessionStorage = function() {
        var obj = jsonParse(sessionStorage.getItem("RedeemFundOder"));
        if (obj) {
            var order = new RedeemFundOder();
            for (var name in obj) {
                order[name] = obj[name];
            }
            return order;
        }
        return null;
    };
    this.getInstanceFromLocalStorage = function() {
        var obj = jsonParse(localStorage.getItem("RedeemFundOder"));
        if (obj) {
            var order = new RedeemFundOder();
            for (var name in obj) {
                order[name] = obj[name];
            }
            return order;
        }
        return null;
    };
}
RedeemFundOder.prototype = new Oder();
